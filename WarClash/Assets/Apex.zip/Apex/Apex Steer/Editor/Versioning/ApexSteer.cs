﻿/* Copyright © 2014 Apex Software. All rights reserved. */
using Apex.Editor.Versioning;

[assembly: ApexProductAttribute("Apex Steer", "1.0.1", ProductType.Product)]
